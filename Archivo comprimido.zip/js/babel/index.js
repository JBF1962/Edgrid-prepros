import menu from './menu'
import migrate from './migrate'

export default { menu, migrate }
